export type LearningPath = {
  slug: string;
  title: string;
  level: string;
  summary: string;
  description: string;
  duration: string;
  prerequisites: string[];
  outcomes: string[];
  modules: { title: string; lessons: string[] }[];
};

export const learningPaths: LearningPath[] = [
  {
    slug: "digital-design-verilog", title: "Digital Design & Verilog", level: "Foundation", duration: "6 weeks",
    summary: "Build strong fundamentals in combinational logic, sequential design, FSMs, and synthesizable RTL.",
    description: "Start with the digital-design concepts used throughout ASIC development, then express those ideas as clean, synthesizable Verilog.",
    prerequisites: ["Basic mathematics", "Curiosity about digital hardware"],
    outcomes: ["Design combinational and sequential circuits", "Write synthesizable Verilog RTL", "Build and verify finite-state machines", "Read waveforms and debug RTL"],
    modules: [
      { title: "Digital foundations", lessons: ["Number systems and Boolean algebra", "Logic gates and minimization", "Combinational building blocks"] },
      { title: "Sequential design", lessons: ["Latches and flip-flops", "Counters and registers", "Setup, hold and clocking basics"] },
      { title: "Verilog RTL", lessons: ["Modules, ports and data types", "Combinational and sequential coding", "Parameters and generate blocks"] },
      { title: "Design practice", lessons: ["FSM architecture", "FIFO design", "Lint and synthesis-ready coding"] },
    ],
  },
  {
    slug: "design-verification", title: "Design Verification", level: "Core", duration: "8 weeks",
    summary: "Learn testbench architecture, assertions, coverage, debugging, and practical verification thinking.",
    description: "Learn how verification engineers convert a specification into a measurable plan and systematically uncover design bugs.",
    prerequisites: ["Verilog fundamentals", "Basic digital design"],
    outcomes: ["Create reusable testbenches", "Write assertions and checkers", "Plan functional coverage", "Debug failures efficiently"],
    modules: [
      { title: "Verification planning", lessons: ["Specification review", "Test planning", "Directed vs constrained-random testing"] },
      { title: "Testbench construction", lessons: ["Stimulus and drivers", "Monitors and scoreboards", "Reference models"] },
      { title: "Assertions & coverage", lessons: ["Immediate and concurrent assertions", "Code coverage", "Functional coverage"] },
      { title: "Debug & closure", lessons: ["Waveform debugging", "Regression triage", "Coverage closure"] },
    ],
  },
  {
    slug: "logic-synthesis", title: "Logic Synthesis", level: "Core", duration: "5 weeks",
    summary: "Turn RTL into optimized gates while reasoning about constraints, timing, power, and area.",
    description: "Understand how synthesis interprets RTL, applies timing constraints, maps logic to standard cells, and reports implementation quality.",
    prerequisites: ["Verilog RTL", "Digital timing basics"],
    outcomes: ["Write and validate SDC constraints", "Read synthesis reports", "Diagnose timing and area issues", "Prepare a clean netlist handoff"],
    modules: [
      { title: "Synthesis flow", lessons: ["Elaboration and linking", "Generic optimization", "Technology mapping"] },
      { title: "Constraints", lessons: ["Clock definitions", "Input and output delays", "Timing exceptions"] },
      { title: "Optimization", lessons: ["Timing, area and power tradeoffs", "Path grouping", "Design-rule constraints"] },
      { title: "Handoff", lessons: ["QoR reports", "Netlist checks", "Equivalence concepts"] },
    ],
  },
  {
    slug: "physical-design", title: "Physical Design", level: "Advanced", duration: "10 weeks",
    summary: "Move from floorplan through placement, CTS, routing, optimization, and GDSII generation.",
    description: "Follow the complete backend flow and learn how congestion, timing, power integrity, clocking, and manufacturability interact.",
    prerequisites: ["Synthesis fundamentals", "STA basics", "Linux and TCL basics"],
    outcomes: ["Create practical floorplans", "Analyze placement and congestion", "Build and debug clock trees", "Route and prepare signoff data"],
    modules: [
      { title: "Introduction to Physical Design", lessons: ["Netlist to layout", "Backend flow stages", "Inputs and outputs"] },
      { title: "Floorplanning", lessons: ["Die and core sizing", "Macro placement", "Utilization and aspect ratio"] },
      { title: "Power Planning", lessons: ["Rings, straps and rails", "Power connectivity", "Early IR-drop thinking"] },
      { title: "Placement", lessons: ["Standard-cell placement", "Legalization", "Timing and congestion optimization"] },
      { title: "Clock Tree Synthesis", lessons: ["Clock latency and skew", "Tree construction", "Post-CTS optimization"] },
      { title: "Routing", lessons: ["Global routing", "Detailed routing", "Parasitic extraction"] },
      { title: "Physical Verification", lessons: ["DRC and LVS", "Antenna checks", "Manufacturing readiness"] },
      { title: "PD Tool Knowledge", lessons: ["Database and views", "Reports and commands", "Flow automation"] },
      { title: "Congestion Analysis", lessons: ["Overflow maps", "Root-cause analysis", "Placement and routing fixes"] },
      { title: "IR Drop and Power Integrity", lessons: ["Static and dynamic IR", "EM awareness", "Power-grid improvement"] },
      { title: "The ECO Flow", lessons: ["Late-stage changes", "Timing ECO", "Metal-only implementation"] },
    ],
  },
  {
    slug: "static-timing-analysis", title: "Static Timing Analysis", level: "Advanced", duration: "7 weeks",
    summary: "Master setup, hold, clock paths, constraints, OCV, and signoff-quality timing analysis.",
    description: "Learn the timing equations and signoff techniques needed to explain, debug, and close real setup and hold violations.",
    prerequisites: ["Digital timing", "Synthesis fundamentals"],
    outcomes: ["Read timing reports confidently", "Debug setup and hold failures", "Apply timing exceptions correctly", "Understand OCV and signoff corners"],
    modules: [
      { title: "Timing foundations", lessons: ["Timing arcs and paths", "Arrival and required time", "Setup and hold equations"] },
      { title: "Constraints", lessons: ["Generated clocks", "Clock uncertainty", "False and multicycle paths"] },
      { title: "Variation", lessons: ["PVT corners", "OCV, AOCV and POCV", "Clock reconvergence pessimism"] },
      { title: "Signoff", lessons: ["MMMC analysis", "Path-based analysis", "Timing ECO strategy"] },
    ],
  },
  {
    slug: "physical-verification", title: "Physical Verification", level: "Signoff", duration: "4 weeks",
    summary: "Understand DRC, LVS, antenna checks, and the final quality gates before tapeout.",
    description: "Learn the physical checks that determine whether a layout matches the design intent and can be manufactured reliably.",
    prerequisites: ["Physical-design flow", "Basic layout knowledge"],
    outcomes: ["Interpret DRC violations", "Debug LVS mismatches", "Understand antenna effects", "Organize a tapeout-ready signoff checklist"],
    modules: [
      { title: "Verification setup", lessons: ["Foundry decks and runsets", "Layout and netlist inputs", "Hierarchy and black boxes"] },
      { title: "DRC", lessons: ["Width, spacing and enclosure", "Density checks", "Violation debugging"] },
      { title: "LVS", lessons: ["Extraction and comparison", "Shorts and opens", "Device mismatches"] },
      { title: "Tapeout checks", lessons: ["Antenna verification", "ERC concepts", "Final signoff checklist"] },
    ],
  },
];

export type SitePage = { title:string; kicker:string; description:string; level:string; duration:string; cards:{title:string;copy:string;topics:string[];href:string;action:string}[]; practice:{title:string;copy:string}[] };
export const sitePages: Record<string, SitePage> = {
  workshops: { title:"Intermediate ASIC courses built around real flow decisions.", kicker:"Courses", description:"Move beyond definitions with structured modules, guided labs, reports and engineering checkpoints across the ASIC lifecycle.", level:"Foundation → Intermediate", duration:"4–10 weeks", cards:[
    {title:"RTL to GDSII",copy:"Connect specification, RTL, synthesis, timing, physical implementation and signoff in one end-to-end course.",topics:["Synthesizable RTL and constraints","Synthesis QoR and netlist handoff","Floorplan through routing","Timing and physical signoff"],href:"/learn/physical-design",action:"Open course"},
    {title:"Physical Design Intermediate",copy:"Build practical judgment for floorplan quality, congestion, power integrity, clock trees and routing closure.",topics:["Macro placement and utilization","Power rings, straps and rails","Placement and CTS optimization","Routing, IR drop and ECOs"],href:"/learn/physical-design",action:"Start physical design"},
    {title:"STA & Constraints",copy:"Read timing reports, define clocks and I/O delays, and debug setup and hold failures across corners.",topics:["Arrival, required time and slack","Generated clocks and exceptions","PVT, OCV and MMMC","Timing ECO selection"],href:"/learn/static-timing-analysis",action:"Start STA course"},
  ],practice:[{title:"Guided lab",copy:"Apply the module to a small design and record inputs, commands, reports and conclusions."},{title:"Checkpoint review",copy:"Use a signoff-style checklist before advancing to the next flow stage."},{title:"160 assignments",copy:"Test each skill with instant correct/wrong feedback and explanations."}]},
  mentorship: { title:"Engineer-led guidance for your next VLSI milestone.", kicker:"Mentorship", description:"Use a focused review cycle: assess the gap, practise the skill, receive technical feedback and demonstrate improvement.", level:"Personalized", duration:"Goal-based", cards:[
    {title:"Learning Roadmap Review",copy:"Turn your current knowledge and target role into a sequenced 6–12 week learning plan.",topics:["Skill-gap assessment","Weekly module sequence","Project and assignment plan","Progress checkpoints"],href:"mailto:asicflowworkshop@gmail.com?subject=Learning%20Roadmap%20Mentorship",action:"Request roadmap review"},
    {title:"Technical Mock Interview",copy:"Practise explaining concepts, reading reports and solving debugging scenarios under interview conditions.",topics:["Role-specific question set","Technical communication","Live follow-up questions","Written improvement notes"],href:"mailto:asicflowworkshop@gmail.com?subject=Technical%20Mock%20Interview",action:"Book mock interview"},
    {title:"Project & Report Review",copy:"Get structured feedback on RTL, SDC, scripts, timing reports or physical-design results.",topics:["Correctness and completeness","Warnings and constraint quality","QoR interpretation","Next-fix prioritization"],href:"mailto:asicflowworkshop@gmail.com?subject=ASIC%20Project%20Review",action:"Request project review"},
  ],practice:[{title:"Bring evidence",copy:"Share a focused artifact such as a waveform, timing path, report excerpt or flow result."},{title:"Explain first",copy:"Present your current understanding before the mentor identifies gaps and corrections."},{title:"Close the loop",copy:"Apply the feedback and return with a corrected result or clearer engineering conclusion."}]},
  "interview-prep": { title:"Prepare for intermediate-level VLSI interviews.", kicker:"Interview preparation", description:"Practise the three skills interviews actually test: concept clarity, report interpretation and engineering judgment.", level:"Intermediate", duration:"Role focused", cards:[
    {title:"Physical Design",copy:"Explain the backend flow and diagnose realistic floorplan, congestion, CTS, routing and power problems.",topics:["Die/core and macro planning","Placement congestion fixes","Skew, latency and clock DRVs","IR drop, routing and ECO tradeoffs"],href:"/assignments",action:"Practise PD questions"},
    {title:"Static Timing Analysis",copy:"Calculate and explain setup/hold behavior, constraints, variation and timing-fix choices.",topics:["Timing-path anatomy","Clock uncertainty and exceptions","OCV, CPPR and MMMC","Setup versus hold ECOs"],href:"/assignments",action:"Practise STA questions"},
    {title:"RTL, DV & Synthesis",copy:"Connect coding style to simulation, coverage, inferred hardware and synthesis quality.",topics:["Blocking/nonblocking behavior","Assertions and coverage closure","Latch and FSM debugging","Constraints and QoR reports"],href:"/assignments",action:"Practise front-end questions"},
  ],practice:[{title:"60-second answer",copy:"State the definition, why it matters and one practical example without wandering."},{title:"Report diagnosis",copy:"Identify the failing metric, likely root cause and the next evidence you would inspect."},{title:"Tradeoff scenario",copy:"Compare at least two fixes and explain their timing, area, power or risk impact."}]},
  blog: { title:"Intermediate engineering notes from the ASIC flow.", kicker:"Banzs insights", description:"Short technical lessons that connect textbook concepts to the reports and decisions used during implementation.", level:"Intermediate reads", duration:"8–12 min each", cards:[
    {title:"Why timing changes after CTS",copy:"Ideal clocks hide insertion delay and real skew. After CTS, propagated clocks change launch/capture relationships and expose clock DRVs.",topics:["Ideal vs propagated clocks","Useful and harmful skew","Post-CTS uncertainty","Setup/hold re-analysis"],href:"/learn/physical-design/clock-tree-synthesis",action:"Read the CTS lesson"},
    {title:"Floorplan mistakes that create congestion",copy:"High local pin density, narrow macro channels and aggressive utilization can make a routable-looking floorplan fail later.",topics:["Macro halos and channels","Pin-access pressure","Density and overflow maps","Early trial-route checks"],href:"/learn/physical-design/floorplanning",action:"Read floorplanning"},
    {title:"How to read synthesis QoR",copy:"A good review checks constraint coverage and warnings before celebrating area, WNS or TNS numbers.",topics:["Unconstrained path checks","WNS, TNS and path groups","Cell area and hierarchy","Latch and high-fanout warnings"],href:"/learn/logic-synthesis/handoff",action:"Read synthesis handoff"},
  ],practice:[{title:"Before reading",copy:"Write your current answer to the article’s main question in two sentences."},{title:"During reading",copy:"Connect every term to a report field, command output or design structure."},{title:"After reading",copy:"Complete related assignments and explain one example without looking at the article."}]},
  community: { title:"Learn with a focused VLSI engineering community.", kicker:"Community", description:"Use structured discussions and study checkpoints to turn questions into reproducible technical learning.", level:"All learning paths", duration:"Ongoing", cards:[
    {title:"Technical Question Clinic",copy:"Submit one focused question with context, evidence, what you expected and what you already tried.",topics:["RTL and waveform debug","SDC and timing reports","Physical-design QoR","DRC and LVS issues"],href:"mailto:asicflowworkshop@gmail.com?subject=Community%20Technical%20Question",action:"Submit a question"},
    {title:"Weekly Study Circle",copy:"Study one connected topic, complete its assignments and discuss the engineering decisions as a group.",topics:["Topic briefing","Independent practice","Peer explanation","Checkpoint quiz"],href:"mailto:asicflowworkshop@gmail.com?subject=Join%20Banzs%20Study%20Circle",action:"Join study circle"},
    {title:"Workshop & Session Updates",copy:"Receive announcements for new batches, free technical sessions and curriculum releases.",topics:["Upcoming workshops","Open learning sessions","Assignment releases","Community challenges"],href:"mailto:asicflowworkshop@gmail.com?subject=Subscribe%20to%20Banzs%20Updates",action:"Get updates"},
  ],practice:[{title:"Ask precisely",copy:"Include the design stage, expected result, actual result and the smallest useful evidence."},{title:"Discuss engineering",copy:"Compare possible root causes and fixes instead of sharing answers without reasoning."},{title:"Document learning",copy:"Close each discussion with the confirmed cause, final fix and reusable takeaway."}]},
};
