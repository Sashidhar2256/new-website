import { notFound } from "next/navigation";
import { learningPaths } from "../../../lib/content";
import { moduleSlug } from "../../../lib/lessons";

export function generateStaticParams() { return learningPaths.map(({ slug }) => ({ slug })); }

export default async function LearningPathPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const path = learningPaths.find((item) => item.slug === slug);
  if (!path) notFound();
  return <main className="inner-page">
    <header className="inner-header"><a className="brand" href="/"><img src="/banzs-team-logo.jpg" alt="Banzs Team"/><span><strong>BANZS</strong><small>ASIC FLOW WORKSHOP</small></span></a><nav><a href="/#paths">All paths</a><a href="/workshops">Workshops</a><a href="/mentorship">Mentorship</a></nav><a className="button button-small" href="mailto:asicflowworkshop@gmail.com">Get started</a></header>
    <section className="path-hero"><div><p className="eyebrow"><span/> {path.level} learning path</p><h1>{path.title}</h1><p>{path.description}</p><div className="course-facts"><span><b>{path.duration}</b> suggested pace</span><span><b>{path.modules.length} modules</b> structured sequence</span></div><a className="button" href={`mailto:asicflowworkshop@gmail.com?subject=${encodeURIComponent(path.title + " enrollment")}`}>Ask about this path</a></div><aside><small>What you will learn</small>{path.outcomes.map((item)=><p key={item}>✓ {item}</p>)}</aside></section>
    <section className="curriculum"><div className="curriculum-title"><p className="eyebrow"><span/> Curriculum</p><h2>Follow the path, module by module.</h2><p>Open every module for the full step-by-step lesson, examples, checklist, and next/previous navigation.</p></div><div className="module-list">{path.modules.map((module,i)=><a className="module-link" href={`/learn/${path.slug}/${moduleSlug(module.title)}`} key={module.title}><span>{String(i+1).padStart(2,"0")}</span><div><h3>{module.title} <b>Open lesson →</b></h3><ul>{module.lessons.map(lesson=><li key={lesson}>{lesson}</li>)}</ul></div></a>)}</div></section>
    <section className="prereq"><div><p className="eyebrow"><span/> Before you begin</p><h2>Prerequisites</h2></div><ul>{path.prerequisites.map(item=><li key={item}>{item}</li>)}</ul></section>
    <section className="closing"><h2>Ready to begin {path.title}?</h2><p>Write to us for the next learning schedule or workshop batch.</p><a className="button button-gold" href="mailto:asicflowworkshop@gmail.com">asicflowworkshop@gmail.com</a></section>
  </main>;
}
