"use client";
import { useMemo,useState } from "react";
import { assignmentQuestions } from "../../lib/assignments";

export default function AssignmentApp(){
  const [difficulty,setDifficulty]=useState("All");const [stage,setStage]=useState("All");const [position,setPosition]=useState(0);const [selected,setSelected]=useState<number|null>(null);const [score,setScore]=useState(0);const [answered,setAnswered]=useState<Set<number>>(new Set());
  const stages=useMemo(()=>["All",...Array.from(new Set(assignmentQuestions.map(q=>q.stage)))],[]);
  const questions=useMemo(()=>assignmentQuestions.filter(q=>(difficulty==="All"||q.difficulty===difficulty)&&(stage==="All"||q.stage===stage)),[difficulty,stage]);
  const current=questions[Math.min(position,questions.length-1)];
  function changeFilters(nextDifficulty:string,nextStage:string){setDifficulty(nextDifficulty);setStage(nextStage);setPosition(0);setSelected(null)}
  function answer(index:number){if(selected!==null)return;setSelected(index);if(!answered.has(current.id)){setAnswered(new Set([...answered,current.id]));if(index===current.answer)setScore(value=>value+1)}}
  function move(delta:number){setPosition(value=>Math.max(0,Math.min(questions.length-1,value+delta)));setSelected(null)}
  function reset(){setPosition(0);setSelected(null);setScore(0);setAnswered(new Set())}
  return <div className="assignment-app"><div className="assignment-toolbar"><label>Difficulty<select value={difficulty} onChange={event=>changeFilters(event.target.value,stage)}><option>All</option><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></label><label>ASIC stage<select value={stage} onChange={event=>changeFilters(difficulty,event.target.value)}>{stages.map(item=><option key={item}>{item}</option>)}</select></label><div className="score"><small>Score</small><b>{score} / {answered.size}</b></div><button onClick={reset}>Reset</button></div>
    <div className="assignment-progress"><span style={{width:`${((position+1)/questions.length)*100}%`}}/></div>
    <article className="question-card"><div className="question-meta"><span>{current.difficulty}</span><span>{current.stage}</span><b>Question {position+1} of {questions.length}</b></div><h2>{current.question}</h2><div className="answer-grid">{current.options.map((option,index)=>{const state=selected===null?"":index===current.answer?"correct":index===selected?"wrong":"muted";return <button className={state} key={option} onClick={()=>answer(index)} disabled={selected!==null}><i>{String.fromCharCode(65+index)}</i><span>{option}</span>{selected!==null&&index===current.answer&&<b>✓</b>}{selected===index&&index!==current.answer&&<b>×</b>}</button>})}</div>{selected!==null&&<div className={`answer-explanation ${selected===current.answer?"is-correct":"is-wrong"}`}><b>{selected===current.answer?"Correct answer":"Not quite"}</b><p>{current.explanation}</p></div>}<div className="question-nav"><button onClick={()=>move(-1)} disabled={position===0}>← Previous</button><span>{answered.size} of {assignmentQuestions.length} answered</span><button onClick={()=>move(1)} disabled={position===questions.length-1}>Next →</button></div></article>
  </div>
}
