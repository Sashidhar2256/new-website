const paths = [
  { n: "01", slug: "digital-design-verilog", title: "Digital Design & Verilog", level: "Foundation", copy: "Build strong fundamentals in combinational logic, sequential design, FSMs, and synthesizable RTL." },
  { n: "02", slug: "design-verification", title: "Design Verification", level: "Core", copy: "Learn testbench architecture, assertions, coverage, debugging, and practical verification thinking." },
  { n: "03", slug: "logic-synthesis", title: "Logic Synthesis", level: "Core", copy: "Turn RTL into optimized gates while reasoning about constraints, timing, power, and area." },
  { n: "04", slug: "physical-design", title: "Physical Design", level: "Advanced", copy: "Move from floorplan through placement, CTS, routing, optimization, and GDSII generation." },
  { n: "05", slug: "static-timing-analysis", title: "Static Timing Analysis", level: "Advanced", copy: "Master setup, hold, clock paths, constraints, OCV, and signoff-quality timing analysis." },
  { n: "06", slug: "physical-verification", title: "Physical Verification", level: "Signoff", copy: "Understand DRC, LVS, antenna checks, and the final quality gates before tapeout." },
];

const flow = ["Specification", "RTL Design", "Verification", "Synthesis", "Place & Route", "Signoff"];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="Banzs Team home">
          <img src="/banzs-team-logo.jpg" alt="Banzs Team ASIC Flow Workshop" />
          <span><strong>BANZS</strong><small>ASIC FLOW WORKSHOP</small></span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#paths">Learn⌄</a>
          <a href="/workshops">Courses⌄</a>
          <a href="/mentorship">Mentorship</a>
          <a href="/interview-prep">Interview prep</a>
          <a href="/blog">Blog</a>
          <a href="/resources">Resources</a>
          <a href="/assignments">Assignments</a>
          <a href="/community">Community</a>
        </nav>
        <a className="button button-small" href="mailto:asicflowworkshop@gmail.com?subject=Banzs%20Team%20Workshop%20Enquiry">Get started</a>
      </header>

      <div className="topic-nav" aria-label="Learning topics">
        {paths.map((path) => <a key={path.title} href={`/learn/${path.slug}`}>{path.title.replace("Digital Design & ", "")}</a>)}
        <a href="/workshops">RTL to GDSII</a><a href="/interview-prep">Interview prep</a>
      </div>

      <section className="section complete-flow-showcase" id="complete-flow">
        <div className="section-heading">
          <div><p className="eyebrow"><span /> Complete workshop map</p><h2>One picture. The complete ASIC journey.</h2></div>
          <p>This 2D technical map connects front-end design, verification, implementation and signoff. Select any learning path below to study each stage in depth.</p>
        </div>
        <figure className="complete-flow-image">
          <img src="/complete-asic-flow-2d.png" alt="Complete ASIC flow from specification, RTL design and functional verification through synthesis, DFT, floorplanning, power planning, placement, CTS, routing, signoff and tapeout" />
          <figcaption><span>FRONT END</span><span>IMPLEMENTATION</span><span>SIGNOFF &amp; SILICON</span></figcaption>
        </figure>
      </section>

      <section className="flow-bar" aria-label="ASIC design flow overview">
        {flow.map((item, i) => <div key={item}><span>{String(i + 1).padStart(2, "0")}</span><strong>{item}</strong>{i < flow.length - 1 && <b aria-hidden="true">→</b>}</div>)}
      </section>

      <section className="section paths" id="paths">
        <div className="section-heading">
          <div><p className="eyebrow"><span /> Structured learning paths</p><h2>Build skills in the right order.</h2></div>
          <p>Every module connects to the real chip-design lifecycle, so you understand not just the tool—but why each step matters.</p>
        </div>
        <div className="path-grid">
          {paths.map((path) => (
            <article className="path-card" key={path.title}>
              <div className="path-meta"><span>{path.n}</span><small>{path.level}</small></div>
              <h3>{path.title}</h3><p>{path.copy}</p>
              <a href={`/learn/${path.slug}`}>Explore path <span aria-hidden="true">↗</span></a>
            </article>
          ))}
        </div>
      </section>

      <section className="section roadmap" id="flow">
        <div className="roadmap-intro">
          <p className="eyebrow light"><span /> Recommended roadmap</p>
          <h2>See how RTL becomes silicon.</h2>
          <p>Follow one connected path from a design idea to a manufacturing-ready layout. Each stage gives you the foundation for the next.</p>
          <a className="button button-gold" href="mailto:asicflowworkshop@gmail.com?subject=ASIC%20Flow%20Learning%20Roadmap">Get the learning roadmap</a>
        </div>
        <ol className="roadmap-steps">
          {flow.map((step, i) => <li key={step}><span>{String(i + 1).padStart(2, "0")}</span><strong>{step}</strong><small>{["Define function, power and performance goals", "Describe the hardware in synthesizable code", "Prove functional intent before implementation", "Map RTL to technology gates", "Floorplan, place, clock and route", "Close timing and physical checks"][i]}</small></li>)}
        </ol>
      </section>

      <section className="section workshop" id="workshops">
        <div className="workshop-card">
          <div className="workshop-copy">
            <p className="eyebrow"><span /> Flagship workshop</p>
            <h2>ASIC Flow Workshop: RTL to GDSII</h2>
            <p>A practical, mentor-led program built around the complete flow. Learn the concepts, read real reports, and connect every implementation stage.</p>
            <ul><li>Live guided sessions</li><li>Hands-on workflow exercises</li><li>Timing and physical-design reports</li><li>Career-focused Q&A</li></ul>
            <a className="button" href="mailto:asicflowworkshop@gmail.com?subject=Register%20for%20ASIC%20Flow%20Workshop">Ask about the next batch <span aria-hidden="true">↗</span></a>
          </div>
          <div className="workshop-panel">
            <span className="panel-kicker">Workshop map</span>
            <div className="mini-flow">{["RTL", "DV", "SYN", "FP", "CTS", "GDS"].map((x, i) => <div key={x}><b>{x}</b><small>0{i + 1}</small></div>)}</div>
            <div className="panel-footer"><span>Format</span><strong>Live + practical</strong><span>Level</span><strong>Foundation to advanced</strong></div>
          </div>
        </div>
      </section>

      <section className="section why" id="about">
        <div className="section-heading"><div><p className="eyebrow"><span /> Why Banzs Team</p><h2>Depth over shortcuts.</h2></div><p>Clear explanations, practical context, and a connected curriculum for learners who want to understand how chips are actually built.</p></div>
        <div className="why-grid">
          <article><span>⌁</span><h3>Complete-flow thinking</h3><p>Learn how front-end decisions affect timing, power, area, and physical implementation.</p></article>
          <article><span>◎</span><h3>Practical workflows</h3><p>Move beyond definitions with report reading, constraints, debugging, and implementation scenarios.</p></article>
          <article><span>◇</span><h3>Engineer-led guidance</h3><p>Ask better questions, build stronger fundamentals, and prepare for real VLSI work.</p></article>
        </div>
      </section>

      <section className="closing">
        <p className="eyebrow light"><span /> Your ASIC journey starts here</p>
        <h2>Ready to follow the flow?</h2>
        <p>Join Banzs Team and learn the path from RTL to reliable silicon.</p>
        <a className="button button-gold" href="mailto:asicflowworkshop@gmail.com?subject=Start%20learning%20with%20Banzs%20Team">Start learning today <span aria-hidden="true">↗</span></a>
      </section>

      <footer>
        <a className="brand footer-brand" href="#top"><img src="/banzs-team-logo.jpg" alt="" /><span><strong>BANZS TEAM</strong><small>ASIC FLOW WORKSHOP</small></span></a>
        <p>Structured VLSI learning from RTL to GDSII.</p>
        <a href="mailto:asicflowworkshop@gmail.com">asicflowworkshop@gmail.com</a>
        <small>© {new Date().getFullYear()} Banzs Team. All rights reserved.</small>
      </footer>
    </main>
  );
}
